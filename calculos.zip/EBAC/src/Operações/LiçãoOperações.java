package Operações;

public class LiçãoOperações {
	public static void main(String[] args) {
		int n1 = 8;
		int n2 = 7;
		int n3 = 9;
		int n4 = 7; 
		int n5 = (n1 + n2 + n3 + n4) / 4 ; 
		System.out.println( n5 );
	}

}
